//
// Created by root on 7/31/24.
//

#ifndef MARKETSHARKCPP_SOUNDDATA_H
#define MARKETSHARKCPP_SOUNDDATA_H


#include <string>
#include "../../decoders/json.hpp"

using json = nlohmann::json;

class SoundData {
public:
    std::string Name;
    float Pitch;

    SoundData() {}

    SoundData(const std::string& name, float pitch)
            : Name(name), Pitch(pitch) {}

    friend void to_json(json& j, const SoundData& s) {
        j = json{{"name", s.Name}, {"pitch", s.Pitch}};
    }

    friend void from_json(const json& j, SoundData& s) {
        j.at("name").get_to(s.Name);
        j.at("pitch").get_to(s.Pitch);
    }
};

#endif //MARKETSHARKCPP_SOUNDDATA_H
