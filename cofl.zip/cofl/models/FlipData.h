//
// Created by root on 7/31/24.
//

#ifndef MARKETSHARKCPP_FLIPDATA_H
#define MARKETSHARKCPP_FLIPDATA_H

#include <string>
#include <vector>
#include "ChatMessageData.h"
#include "SoundData.h"
#include "../../decoders/json.hpp"

using json = nlohmann::json;

class FlipData {
public:
    std::vector<ChatMessageData> Messages;
    std::string Id;
    int Worth;
    SoundData Sound;
    std::string Render;

    FlipData() {}

    FlipData(const std::vector<ChatMessageData>& messages, const std::string& id, int worth, const SoundData& sound, const std::string& render)
            : Messages(messages), Id(id), Worth(worth), Sound(sound), Render(render) {}

    friend void to_json(json& j, const FlipData& f) {
        j = json{{"messages", f.Messages}, {"id", f.Id}, {"worth", f.Worth}, {"sound", f.Sound}, {"render", f.Render}};
    }

    friend void from_json(const json& j, FlipData& f) {
        j.at("messages").get_to(f.Messages);
        j.at("id").get_to(f.Id);
        j.at("worth").get_to(f.Worth);
        j.at("sound").get_to(f.Sound);
        j.at("render").get_to(f.Render);
    }
};

#endif //MARKETSHARKCPP_FLIPDATA_H
